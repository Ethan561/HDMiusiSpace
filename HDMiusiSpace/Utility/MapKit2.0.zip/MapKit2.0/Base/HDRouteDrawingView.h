//
//  HDRouteDrawingView.h
//  HDGansuKJG
//
//  Created by liuyi on 2018/10/31.
//  Copyright © 2018年 hengdawb. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HDRouteDrawingView : UIView

@property (nonatomic, strong) NSArray *pointArray;
@property (nonatomic, assign) CGFloat mapZoomScale;

@end
