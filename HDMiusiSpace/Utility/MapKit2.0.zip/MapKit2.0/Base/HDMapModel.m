//
//  HDMapModel.m
//  HDGansuKJG
//
//  Created by liuyi on 2018/10/31.
//  Copyright © 2018年 hengdawb. All rights reserved.
//

#import "HDMapModel.h"

@implementation HDMapModel

+ (instancetype)mapPoiWithDict:(NSDictionary *)dict
{
    return [[self alloc] initWithDic:dict];
}


@end
